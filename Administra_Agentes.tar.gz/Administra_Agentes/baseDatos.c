/* librerías que usaremos */
/*Primero debemos verificar que existan las librerias. con el comando 
$mysql_config --libs
si no se instala con el comando
sudo apt-get install libmysqlclient-dev

una vez instalado configuramos con los comandos
$mysql_config --cflags
$mysql_config --libs

*/
/*Para compilar  $gcc -o Archivo_de_salida $(mysql_config --cflags) Archivo.c $(mysql_config --libs)	*/

#include <mysql/mysql.h> /* libreria que nos permite hacer el uso de las conexiones y consultas con MySQL */
#include <string.h>	

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
//#include <openssl/sha.h>//libreria para obtener el digesto 

/*
funcion para insertar en la base de datos los valores que envia el agente
*/

void AlmacenaProcesos(char *cadena,char *direccionIP){
	MYSQL *conn; /* variable de conexión para MySQL */
	MYSQL_RES *res; /* variable que contendra el res	ultado de la consuta */
	MYSQL_ROW row; /* variable que contendra los campos por cada registro consultado */
	char *server = "localhost"; /*direccion del servidor 127.0.0.1, localhost o direccion ip */
	char *user = "root"; /*usuario para consultar la base de datos */
	char *password = "d4n13l.f"; /* contraseña para el usuario en cuestion */
	char *database = "Trabajo_Terminal_II"; /*nombre de la base de datos a consultar */
	conn = mysql_init(NULL); /*inicializacion a nula la conexión */
	char query[200];	
	char *ptr;
	char *aux[5];
	int corre =0;	

	char *la_prueba;
	la_prueba = cadena;

	/* conectar a la base de datos */
	if (!mysql_real_connect(conn, server, user, password, database, 0, NULL, 0))
	{ /* definir los parámetros de la conexión antes establecidos */
		fprintf(stderr, "%s\n", mysql_error(conn)); /* si hay un error definir cual fue dicho error */
		exit(1);
	}
	printf("conexion realizada con exito \n");
	
	//formato de entrada
	//numero_opcion;nombre del usuario;nombre del proceso;fecha inicio del proceso;.

	ptr = strtok( la_prueba,";" );    // Primera llamada => Primer token
	aux[0]= ptr;
	corre++;
  	printf( "%s\n", ptr );
   	while( (ptr = strtok( NULL,";" )) != NULL ){    // Posteriores llamadas
     	printf( "%s\n", ptr );
	aux[corre]=ptr;
	printf("corre en pos %d dice %s \n",corre,aux[corre]);
	corre++;	
	}
	
	printf("termina while\n");
/*
ID int auto_increment primary key not null,
agente varchar(15),
user varchar(50),
nombre_proc varchar(100),
inicio_proc varchar(100),
fin_proc varchar(100)
*/

	strcpy(query,"insert into Mon_Proc values (NULL,'");
	strcat(query,direccionIP);//direccion IP
	strcat(query,"','");
	strcat(query,aux[1]);//nombre del usuario formato Dominio/usuario
	strcat(query,"','");
	strcat(query,aux[2]);//nombre del proceso
	strcat(query,"','");
	strcat(query,aux[3]);//inicio del proceso
	strcat(query,"',NULL");//fin del proceo en null	
	strcat(query,")");
	
	printf("%s\n",query);
	/* enviar consulta SQL */
	if (mysql_query(conn,query))
	{ /* definicion de la consulta y el origen de la conexion */
		fprintf(stderr, "%s\n", mysql_error(conn));
		//exit(1);
	}

	if (mysql_query(conn,"select * from Mon_Proc"))
	{ /* definicion de la consulta y el origen de la conexion */
		fprintf(stderr, "%s\n", mysql_error(conn));
		//exit(1);
	}

	res = mysql_use_result(conn);
	printf("ID\tDireccionIP\t\tusuario\t\tnombre proceso\t\t fecha inicio\n");
	while ((row = mysql_fetch_row(res)) != NULL) /* recorrer la variable res con todos los registros obtenidos para su uso */
		printf("%s\t%s\t%s\t%s\t%s \n", row[0],row[1],row[2],row[3],row[4]); /* la variable row se convierte en un	 arreglo por el numero de campos que hay en la tabla */

	/* se libera la variable res y se cierra la conexión */
	mysql_free_result(res);
	mysql_close(conn);
}

void AlmacenaRenombre(char *cadena,char *direccionIP){

	//Caso 3 almacena renombre de archivos y carpetas

	

	MYSQL *conn; /* variable de conexión para MySQL */
	MYSQL_RES *res; /* variable que contendra el res	ultado de la consuta */
	MYSQL_ROW row; /* variable que contendra los campos por cada registro consultado */
	char *server = "localhost"; /*direccion del servidor 127.0.0.1, localhost o direccion ip */
	char *user = "root"; /*usuario para consultar la base de datos */
	char *password = "d4n13l.f"; /* contraseña para el usuario en cuestion */
	char *database = "prueba"; /*nombre de la base de datos a consultar */
	conn = mysql_init(NULL); /*inicializacion a nula la conexión */
	char query[200];	
	char *ptr;
	char *aux[8];
	int corre =0;	

	char *la_prueba;
	la_prueba = cadena;

	/* conectar a la base de datos */
	if (!mysql_real_connect(conn, server, user, password, database, 0, NULL, 0))
	{ /* definir los parámetros de la conexión antes establecidos */
		fprintf(stderr, "%s\n", mysql_error(conn)); /* si hay un error definir cual fue dicho error */
		exit(1);
	}
	printf("conexion realizada con exito \n");

	//formato de entrada	
	//numero_opcion;nombre del usuario;ruta completa del archivo antes ;ruta completa del archivo despues;RENOMBRE;momento en el que registro el evento.
	
	ptr = strtok( la_prueba,";" );    // Primera llamada => Primer token
	aux[0]= ptr;
	corre++;
  	printf( "%s\n", ptr );
   	while( (ptr = strtok( NULL,";" )) != NULL ){    // Posteriores llamadas
     	printf( "%s\n", ptr );
	aux[corre]=ptr;
	printf("corre en pos %d dice %s \n",corre,aux[corre]);
	corre++;	
	}
	
	printf("termina while\n");
/*
create table Mon_files(
ID int auto_increment primary key not null,
agente varchar(15),
user varchar(50),
archivo varchar(200),
archivo_despues varchar(200),
tipo_cambio varchar(50),
momento_de_cambio varchar(50)
);
*/

	strcpy(query,"insert into Mon_files values (NULL,'");
	strcat(query,direccionIP);//direccion IP
	strcat(query,"','");
	strcat(query,aux[1]);//nombre del usuario formato Dominio/usuario
	strcat(query,"','");
	strcat(query,aux[2]);//ruta completa del archivo antes 
	strcat(query,"','");
	strcat(query,aux[3]);//ruta completa del archivo despues 
	strcat(query,"','");
	strcat(query,aux[4]);//tipo del cambio
	strcat(query,"','");
	strcat(query,aux[5]);//momento del cambio
	strcat(query,")");
	
	printf("%s\n",query);
	/* enviar consulta SQL */
	if (mysql_query(conn,query))
	{ /* definicion de la consulta y el origen de la conexion */
		fprintf(stderr, "%s\n", mysql_error(conn));
		//exit(1);
	}

	/*if (mysql_query(conn,"select * from Mon_Files"))
	{ // definicion de la consulta y el origen de la conexion 
		fprintf(stderr, "%s\n", mysql_error(conn));
		//exit(1);
	}

	res = mysql_use_result(conn);
	printf("ID\tM\t\tedad\n");
	while ((row = mysql_fetch_row(res)) != NULL) // recorrer la variable res con todos los registros obtenidos para su uso 
		printf("%s\t%s\t%s \n", row[0],row[1],row[2]); // la variable row se convierte en un arreglo por el numero de campos que hay en la tabla
	*/
	/* se libera la variable res y se cierra la conexión */
	mysql_free_result(res);
	mysql_close(conn);
}

void AlmacenaCambio(char *cadena,char *direccionIP){

	//Caso 4 almacena cambio en archivos y carpetas
	

	MYSQL *conn; /* variable de conexión para MySQL */
	MYSQL_RES *res; /* variable que contendra el res	ultado de la consuta */
	MYSQL_ROW row; /* variable que contendra los campos por cada registro consultado */
	char *server = "localhost"; /*direccion del servidor 127.0.0.1, localhost o direccion ip */
	char *user = "root"; /*usuario para consultar la base de datos */
	char *password = "d4n13l.f"; /* contraseña para el usuario en cuestion */
	char *database = "prueba"; /*nombre de la base de datos a consultar */
	conn = mysql_init(NULL); /*inicializacion a nula la conexión */
	char query[200];	
	char *ptr;
	char *aux[3];
	int corre =0;	

	char *la_prueba;
	la_prueba = cadena;

	/* conectar a la base de datos */
	if (!mysql_real_connect(conn, server, user, password, database, 0, NULL, 0))
	{ /* definir los parámetros de la conexión antes establecidos */
		fprintf(stderr, "%s\n", mysql_error(conn)); /* si hay un error definir cual fue dicho error */
		exit(1);
	}
	printf("conexion realizada con exito \n");

	//formato de entrada	
	//numero_opcion;nombre del usuario;ruta completa del archivo;tipo de cambio;momento en el que registro el evento.
	
	ptr = strtok( la_prueba,";" );    // Primera llamada => Primer token
	aux[0]= ptr;
	corre++;
  	printf( "%s\n", ptr );
   	while( (ptr = strtok( NULL,";" )) != NULL ){    // Posteriores llamadas
     	printf( "%s\n", ptr );
	aux[corre]=ptr;
	printf("corre en pos %d dice %s \n",corre,aux[corre]);
	corre++;	
	}
	
	printf("termina while\n");
/*
create table Mon_files(
ID int auto_increment primary key not null,
agente varchar(15),
user varchar(50),
archivo varchar(200),
archivo_despues varchar(200),
tipo_cambio varchar(50),
momento_de_cambio varchar(50)
);
*/

	strcpy(query,"insert into Mon_files values (NULL,'");
	strcat(query,direccionIP);//direccion IP
	strcat(query,"','");
	strcat(query,aux[1]);//nombre del usuario formato Dominio/usuario
	strcat(query,"','");
	strcat(query,aux[2]);//ruta completa del archivo antes 
	strcat(query,"',NULL,'");
	strcat(query,aux[3]);//tipo de cambio
	strcat(query,"','");
	strcat(query,aux[4]);//momento del cambio
	strcat(query,")");
	
	printf("%s\n",query);
	/* enviar consulta SQL */
	if (mysql_query(conn,query))
	{ /* definicion de la consulta y el origen de la conexion */
		fprintf(stderr, "%s\n", mysql_error(conn));
		//exit(1);
	}

	/*if (mysql_query(conn,"select * from Mon_Files"))
	{ // definicion de la consulta y el origen de la conexion 
		fprintf(stderr, "%s\n", mysql_error(conn));
		//exit(1);
	}

	res = mysql_use_result(conn);
	printf("ID\tM\t\tedad\n");
	while ((row = mysql_fetch_row(res)) != NULL) // recorrer la variable res con todos los registros obtenidos para su uso 
		printf("%s\t%s\t%s \n", row[0],row[1],row[2]); // la variable row se convierte en un arreglo por el numero de campos que hay en la tabla
	*/
	/* se libera la variable res y se cierra la conexión */
	mysql_free_result(res);
	mysql_close(conn);
}


void AlmacenaBorrado(char *cadena,char *direccionIP){

	//Caso 5 almacena borrado de archivos y carpetas
	

	MYSQL *conn; /* variable de conexión para MySQL */
	MYSQL_RES *res; /* variable que contendra el res	ultado de la consuta */
	MYSQL_ROW row; /* variable que contendra los campos por cada registro consultado */
	char *server = "localhost"; /*direccion del servidor 127.0.0.1, localhost o direccion ip */
	char *user = "root"; /*usuario para consultar la base de datos */
	char *password = "d4n13l.f"; /* contraseña para el usuario en cuestion */
	char *database = "prueba"; /*nombre de la base de datos a consultar */
	conn = mysql_init(NULL); /*inicializacion a nula la conexión */
	char query[200];	
	char *ptr;
	char *aux[3];
	int corre =0;	

	char *la_prueba;
	la_prueba = cadena;

	/* conectar a la base de datos */
	if (!mysql_real_connect(conn, server, user, password, database, 0, NULL, 0))
	{ /* definir los parámetros de la conexión antes establecidos */
		fprintf(stderr, "%s\n", mysql_error(conn)); /* si hay un error definir cual fue dicho error */
		exit(1);
	}
	printf("conexion realizada con exito \n");

	//formato de entrada	
	//numero_opcion;nombre del usuario;ruta completa del archivo;tipo de cambio;momento en el que registro el evento.
	
	ptr = strtok( la_prueba,";" );    // Primera llamada => Primer token
	aux[0]= ptr;
	corre++;
  	printf( "%s\n", ptr );
   	while( (ptr = strtok( NULL,";" )) != NULL ){    // Posteriores llamadas
     	printf( "%s\n", ptr );
	aux[corre]=ptr;
	printf("corre en pos %d dice %s \n",corre,aux[corre]);
	corre++;	
	}
	
	printf("termina while\n");
/*
create table Mon_files(
ID int auto_increment primary key not null,
agente varchar(15),
user varchar(50),
archivo varchar(200),
archivo_despues varchar(200),
tipo_cambio varchar(50),
momento_de_cambio varchar(50)
);
*/

	strcpy(query,"insert into Mon_files values (NULL,'");
	strcat(query,direccionIP);//direccion IP
	strcat(query,"','");
	strcat(query,aux[1]);//nombre del usuario formato Dominio/usuario
	strcat(query,"','");
	strcat(query,aux[2]);//ruta completa del archivo antes 
	strcat(query,"',NULL,'");
	strcat(query,aux[3]);//tipo de cambio
	strcat(query,"','");
	strcat(query,aux[4]);//momento del cambio
	strcat(query,")");
	
	printf("%s\n",query);
	/* enviar consulta SQL */
	if (mysql_query(conn,query))
	{ /* definicion de la consulta y el origen de la conexion */
		fprintf(stderr, "%s\n", mysql_error(conn));
		//exit(1);
	}

	/*if (mysql_query(conn,"select * from Mon_Files"))
	{ // definicion de la consulta y el origen de la conexion 
		fprintf(stderr, "%s\n", mysql_error(conn));
		//exit(1);
	}

	res = mysql_use_result(conn);
	printf("ID\tM\t\tedad\n");
	while ((row = mysql_fetch_row(res)) != NULL) // recorrer la variable res con todos los registros obtenidos para su uso 
		printf("%s\t%s\t%s \n", row[0],row[1],row[2]); // la variable row se convierte en un arreglo por el numero de campos que hay en la tabla
	*/
	/* se libera la variable res y se cierra la conexión */
	mysql_free_result(res);
	mysql_close(conn);
}

void AlmacenaFinProcesos(char *cadena, char *direccionIP){

	//Caso 6 almacena el fin de ejecucion de un proceso
	

	MYSQL *conn; /* variable de conexión para MySQL */
	MYSQL_RES *res; /* variable que contendra el res	ultado de la consuta */
	MYSQL_ROW row; /* variable que contendra los campos por cada registro consultado */
	char *server = "localhost"; /*direccion del servidor 127.0.0.1, localhost o direccion ip */
	char *user = "root"; /*usuario para consultar la base de datos */
	char *password = "d4n13l.f"; /* contraseña para el usuario en cuestion */
	char *database = "prueba"; /*nombre de la base de datos a consultar */
	conn = mysql_init(NULL); /*inicializacion a nula la conexión */
	char query[200];	
	char *ptr;
	char *aux[3];
	int corre =0;	

	char *la_prueba;
	la_prueba = cadena;

	/* conectar a la base de datos */
	if (!mysql_real_connect(conn, server, user, password, database, 0, NULL, 0))
	{ /* definir los parámetros de la conexión antes establecidos */
		fprintf(stderr, "%s\n", mysql_error(conn)); /* si hay un error definir cual fue dicho error */
		exit(1);
	}
	printf("conexion realizada con exito \n");

	//formato de entrada	
	//numero_opcion;nombre del usuario;nombre del proceso;momento en el que termino.
	
	ptr = strtok( la_prueba,";" );    // Primera llamada => Primer token
	aux[0]= ptr;
	corre++;
  	printf( "%s\n", ptr );
   	while( (ptr = strtok( NULL,";" )) != NULL ){    // Posteriores llamadas
     	printf( "%s\n", ptr );
	aux[corre]=ptr;
	printf("corre en pos %d dice %s \n",corre,aux[corre]);
	corre++;	
	}
	
	printf("termina while\n");
/*
ID int auto_increment primary key not null,
agente varchar(15),
user varchar(50),
nombre_proc varchar(100),
inicio_proc varchar(100),
fin_proc varchar(100)
*/

	strcpy(query,"UPDATE Mon_Proc set fin_proc ='");
	strcat(query,aux[3]);//momento en el que termina
	strcat(query,"where agente = '");
	strcat(query,direccionIP);
	strcat(query,"' and user = '");
	strcat(query,aux[1]);//nombre del usuario formato Dominio/usuario 
	strcat(query,"' and nobre_proc ='");
	strcat(query,aux[2]);//nombre del proceso
	strcat(query,"')");
	
	printf("%s\n",query);
	/* enviar consulta SQL */
	if (mysql_query(conn,query))
	{ /* definicion de la consulta y el origen de la conexion */
		fprintf(stderr, "%s\n", mysql_error(conn));
		//exit(1);
	}

	/*if (mysql_query(conn,"select * from Mon_Files"))
	{ // definicion de la consulta y el origen de la conexion 
		fprintf(stderr, "%s\n", mysql_error(conn));
		//exit(1);
	}

	res = mysql_use_result(conn);
	printf("ID\tM\t\tedad\n");
	while ((row = mysql_fetch_row(res)) != NULL) // recorrer la variable res con todos los registros obtenidos para su uso 
		printf("%s\t%s\t%s \n", row[0],row[1],row[2]); // la variable row se convierte en un arreglo por el numero de campos que hay en la tabla
	*/
	/* se libera la variable res y se cierra la conexión */
	mysql_free_result(res);
	mysql_close(conn);
}

void AlmacenaEquipoNuevo(char *direccionIP){
	MYSQL *conn; /* variable de conexión para MySQL */
	MYSQL_RES *res; /* variable que contendra el res	ultado de la consuta */
	MYSQL_ROW row; /* variable que contendra los campos por cada registro consultado */
	char *server = "localhost"; /*direccion del servidor 127.0.0.1, localhost o direccion ip */
	char *user = "root"; /*usuario para consultar la base de datos */
	char *password = "d4n13l.f"; /* contraseña para el usuario en cuestion */
	char *database = "Trabajo_Terminal_II"; /*nombre de la base de datos a consultar */
	conn = mysql_init(NULL); /*inicializacion a nula la conexión */
	char query[200];
	char dir[16];	

	/* conectar a la base de datos */
	if (!mysql_real_connect(conn, server, user, password, database, 0, NULL, 0))
	{ /* definir los parámetros de la conexión antes establecidos */
		fprintf(stderr, "%s\n", mysql_error(conn)); /* si hay un error definir cual fue dicho error */
		//exit(1);
	}
	//printf("conexion realizada con exito \n");
	//printf("%s",direccionIP);

	strcpy(dir,direccionIP);
	
	//printf("%s\n",dir);
	

/*
create table Equipos(
ID_equipo int auto_increment primary key not null,
Direccion_IP varchar(15),
digesto_de_verificacion varchar(32),
verificado varchar(2),
conectado varchar(2),
respuesta_activa varchar(2)
);
*/

	strcpy(query,"select count(*) as existe from Equipos where Direccion_IP = '");
	strcat(query,direccionIP);//direccion IP
	strcat(query,"'");

	//printf("%s\n",query);

	if (mysql_query(conn,query))
	{ /* definicion de la consulta y el origen de la conexion */
		fprintf(stderr, "%s\n	", mysql_error(conn));
		//exit(1);
	}

	res = mysql_use_result(conn);
	row = mysql_fetch_row(res); /* recorrer la variable res con todos los registros obtenidos para su uso **/

	//printf("%d ",atoi(row[0]));

	int i;
	if (atoi(row[0]) < 1){
	/*unsigned char aux[SHA_DIGEST_LENGTH];
	//unsigned char digesto[SHA_DIGEST_LENGTH];
	SHA(direccionIP,sizeof(direccionIP)-1,aux);
	for(i=0;i<SHA_DIGEST_LENGTH;i++)	
	printf("%02x",aux[i]);

	printf("\n");*/
	//strcpy(digesto,"12345689");

	strcpy(query,"insert into Equipos values (NULL,'");
	strcat(query,direccionIP);//direccion IP
	strcat(query,"',sha('");
	strcat(query,direccionIP);//nombre del usuario formato Dominio/usuario
	strcat(query,"'),'NO','NO','NO')");
	mysql_free_result(res);
	//	printf("%s\n",query);
	/* enviar consulta SQL */
	if (mysql_query(conn,query))
	{ /* definicion de la consulta y el origen de la conexion */
		fprintf(stderr, "%s\n", mysql_error(conn));
		//exit(1);
	}

	if (mysql_query(conn,"select * from Equipos"))
	{ /* definicion de la consulta y el origen de la conexion */
		fprintf(stderr, "%s\n", mysql_error(conn));
		//exit(1);
	}

	res = mysql_use_result(conn);
	printf("\t\nAgente Registrado con exito\t\n");
	printf("ID\tEquipo\t\tdigesto\t\n");
	while ((row = mysql_fetch_row(res)) != NULL) /* recorrer la variable res con todos los registros obtenidos para su uso */
		printf("%s\t%s\t%s \n", row[0],row[1],row[2]); /* la variable row se convierte en un arreglo por el numero de campos que hay en la tabla */

	/* se libera la variable res y se cierra la conexión */
	mysql_free_result(res);
	mysql_close(conn);
}
else
printf("el agente %s ya está registrado\n",direccionIP);
}

int ValidaEquipo(char *direccionIP, char *digesto){
	MYSQL *conn; /* variable de conexión para MySQL */
	MYSQL_RES *res; /* variable que contendra el res	ultado de la consuta */
	MYSQL_ROW row; /* variable que contendra los campos por cada registro consultado */
	char *server = "localhost"; /*direccion del servidor 127.0.0.1, localhost o direccion ip */
	char *user = "root"; /*usuario para consultar la base de datos */
	char *password = "d4n13l.f"; /* contraseña para el usuario en cuestion */
	char *database = "Trabajo_Terminal_II"; /*nombre de la base de datos a consultar */
	conn = mysql_init(NULL); /*inicializacion a nula la conexión */
	char query[200];
	char dirIP[15];
	char hash[22];	

	/* conectar a la base de datos */
	if (!mysql_real_connect(conn, server, user, password, database, 0, NULL, 0))
	{ /* definir los parámetros de la conexión antes establecidos */
		fprintf(stderr, "%s\n", mysql_error(conn)); /* si hay un error definir cual fue dicho error */
		//exit(1);
	return 1; 
	}
	printf("conexion realizada con exito \n");
	
	strcpy(dirIP,direccionIP);
	strcpy(hash,digesto);	
	printf("DireccionIP: %s \n",direccionIP);
	printf("Hash %s \n",digesto);

/*
create table Equipos(
ID int auto_increment primary key not null,
Direccion_IP varchar(15),
digesto_de_verificacion varchar(32),
verificado varchar(2),
conectado varchar(2)
);
*/

	strcpy(query,"select count(*) as existe from Equipos where Direccion_IP = '");
	printf("longitud %s \n ",query);	
	strcat(query,direccionIP);//direccion IP

	strcat(query,"'");
	
	
	printf("%s \n",query);

	if (mysql_query(conn,query))
	{ /* definicion de la consulta y el origen de la conexion */
		fprintf(stderr, "%s\n", mysql_error(conn));
		//exit(1);
	return 1;
	}

	res = mysql_use_result(conn);
	row = mysql_fetch_row(res); /* recorrer la variable res con todos los registros obtenidos para su uso **/

	if (atoi(row[0]) == 1){

	mysql_free_result(res);
	
	strcpy(query,"update Equipos set verificado= 'SI' where Direccion_IP ='");
	strcat(query,direccionIP);//direccion IP
	strcat(query,"'and digesto_de_verificacion ='");
	strcat(query,hash);//nombre del usuario formato Dominio/usuario
	strcat(query,"'");
	
	printf("%s\n",query);
	/* enviar consulta SQL regresa 0 si se ejecuta correctamente, otro numero si se ejecuta mal*/
	if (mysql_query(conn,query))
	{ /* definicion de la consulta y el origen de la conexion */
		fprintf(stderr, "%s\n", mysql_error(conn));
		return 1;
		//exit(1);
	}

	if (mysql_query(conn,"select * from Equipos"))
	{ /* definicion de la consulta y el origen de la conexion */
		fprintf(stderr, "%s\n", mysql_error(conn));
		//exit(1);
	return 1;
	}

	res = mysql_use_result(conn);
	printf("ID\tEquipo\t\tdigesto\tverificado\n");
	while ((row = mysql_fetch_row(res)) != NULL) /* recorrer la variable res con todos los registros obtenidos para su uso */
		printf("%s\t%s\t%s\t%s \n", row[0],row[1],row[2],row[3]); /* la variable row se convierte en un arreglo por el numero de campos que hay en la tabla */

	/* se libera la variable res y se cierra la conexión */
	mysql_free_result(res);
	mysql_close(conn);
	return 0;
	}
	else{
	printf("\t\t\n\nEl agente no está registrado\t\t\n\n");
	return 1;
	}
}



int Conectado(char *direccionIP){
	MYSQL *conn; /* variable de conexión para MySQL */
	MYSQL_RES *res; /* variable que contendra el res	ultado de la consuta */
	MYSQL_ROW row; /* variable que contendra los campos por cada registro consultado */
	char *server = "localhost"; /*direccion del servidor 127.0.0.1, localhost o direccion ip */
	char *user = "root"; /*usuario para consultar la base de datos */
	char *password = "d4n13l.f"; /* contraseña para el usuario en cuestion */
	char *database = "Trabajo_Terminal_II"; /*nombre de la base de datos a consultar */
	conn = mysql_init(NULL); /*inicializacion a nula la conexión */
	char query[200];	

	/* conectar a la base de datos */
	if (!mysql_real_connect(conn, server, user, password, database, 0, NULL, 0))
	{ /* definir los parámetros de la conexión antes establecidos */
		fprintf(stderr, "%s\n", mysql_error(conn)); /* si hay un error definir cual fue dicho error */
		//exit(1);
	return 1;
	}
	printf("conexion realizada con exito \n");
/*
create table Equipos(
ID int auto_increment primary key not null,
Direccion_IP varchar(15),
digesto_de_verificacion varchar(32),
verificado varchar(2),
conectado varchar(2)
);
*/


	strcpy(query,"Select count(*) as existe from Equipos where Direccion_IP ='");
	strcat(query,direccionIP);//direccion IP
	strcat(query,"'and verificado = 'SI'");

	printf("%s \n",query);

	if (mysql_query(conn,query))
	{ /* definicion de la consulta y el origen de la conexion */
		fprintf(stderr, "%s\n", mysql_error(conn));
		return 1;
		//exit(1);
	}

	res = mysql_use_result(conn);	

	row = mysql_fetch_row(res);
	
	if(atoi(row[0])==1){	

	mysql_free_result(res);

	strcpy(query,"update Equipos set conectado= 'SI' where Direccion_IP = '");
	strcat(query,direccionIP);//direccion IP
	strcat(query,"'");



	printf("%s\n",query);
	/* enviar consulta SQL regresa 0 si se ejecuta correctamente, otro numero si se ejecuta mal*/
	if (mysql_query(conn,query))
	{ /* definicion de la consulta y el origen de la conexion */
		fprintf(stderr, "%s\n", mysql_error(conn));
		return 1;
		//exit(1);
	}

	if (mysql_query(conn,"select * from Equipos"))
	{ /* definicion de la consulta y el origen de la conexion */
		fprintf(stderr, "%s\n", mysql_error(conn));
		//exit(1);
	return 1;
	}

	res = mysql_use_result(conn);
	printf("ID\tEquipo\t\tdigesto\tverificado\tverificado\n");
	while ((row = mysql_fetch_row(res)) != NULL) /* recorrer la variable res con todos los registros obtenidos para su uso */
		printf("%s\t%s\t%s\t%s \t%s\n", row[0],row[1],row[2],row[3],row[4]); /* la variable row se convierte en un arreglo por el numero de campos que hay en la tabla */

	/* se libera la variable res y se cierra la conexión */
	mysql_free_result(res);
	mysql_close(conn);
	return 0;
	}
	else{
	
	printf("La direccion IP no existe o no está validada\n");
	return	1;
	}

}

int PuedeConectarse(char *direccionIP){
	MYSQL *conn; /* variable de conexión para MySQL */
	MYSQL_RES *res; /* variable que contendra el res	ultado de la consuta */
	MYSQL_ROW row; /* variable que contendra los campos por cada registro consultado */
	char *server = "localhost"; /*direccion del servidor 127.0.0.1, localhost o direccion ip */
	char *user = "root"; /*usuario para consultar la base de datos */
	char *password = "d4n13l.f"; /* contraseña para el usuario en cuestion */
	char *database = "Trabajo_Terminal_II"; /*nombre de la base de datos a consultar */
	conn = mysql_init(NULL); /*inicializacion a nula la conexión */
	char query[200];

	/* conectar a la base de datos */
	if (!mysql_real_connect(conn, server, user, password, database, 0, NULL, 0))
	{ /* definir los parámetros de la conexión antes establecidos */
		fprintf(stderr, "%s\n", mysql_error(conn)); /* si hay un error definir cual fue dicho error */
		return 1;//exit(1);
	}
	printf("conexion realizada con exito \n");
/*
create table Equipos(
ID int auto_increment primary key not null,
Direccion_IP varchar(15),
digesto_de_verificacion varchar(32),
verificado varchar(2),
conectado varchar(2)
);
*/


	strcpy(query,"Select count(*) as existe from Equipos where Direccion_IP ='");
	strcat(query,direccionIP);//direccion IP
	strcat(query,"',and verificado = 'SI'");

	if (mysql_query(conn,query))
	{ /* definicion de la consulta y el origen de la conexion */
		fprintf(stderr, "%s\n", mysql_error(conn));
		//exit(1);
	return 1;
	}

	res = mysql_use_result(conn);	

	row = mysql_fetch_row(res);
	
	if(atoi(row[0])==1){	

	mysql_free_result(res);

	mysql_close(conn);
	return 0;
	}
	else{
	mysql_free_result(res);
	mysql_close(conn);	
	printf("La direccion IP no existe o no está validada\n");
	return 1;
	}

}


void ObtieneDigesto(char *direccionIP){
	MYSQL *conn; /* variable de conexión para MySQL */
	MYSQL_RES *res; /* variable que contendra el res	ultado de la consuta */
	MYSQL_ROW row; /* variable que contendra los campos por cada registro consultado */
	char *server = "localhost"; /*direccion del servidor 127.0.0.1, localhost o direccion ip */
	char *user = "root"; /*usuario para consultar la base de datos */
	char *password = "d4n13l.f"; /* contraseña para el usuario en cuestion */
	char *database = "Trabajo_Terminal_II"; /*nombre de la base de datos a consultar */
	conn = mysql_init(NULL); /*inicializacion a nula la conexión */
	char query[200];	
	
	char digesto[23];

	/* conectar a la base de datos */
	if (!mysql_real_connect(conn, server, user, password, database, 0, NULL, 0))
	{ /* definir los parámetros de la conexión antes establecidos */
		fprintf(stderr, "%s\n", mysql_error(conn)); /* si hay un error definir cual fue dicho error */
		//exit(1);
		return;
	}
	//printf("conexion realizada con exito \n");

/*
create table Equipos(
ID int auto_increment primary key not null,
Direccion_IP varchar(15),
digesto_de_verificacion varchar(32),
verificado varchar(2),
conectado varchar(2)
);
*/
	strcpy(query,"Select count(*) as existe from Equipos where Direccion_IP ='");
	strcat(query,direccionIP);//direccion IP
	strcat(query,"'");

	if (mysql_query(conn,query))
	{ /* definicion de la consulta y el origen de la conexion */
		fprintf(stderr, "%s\n", mysql_error(conn));
		return;
		//exit(1);
	}

	res = mysql_use_result(conn);	

	row = mysql_fetch_row(res);

	
	
	if(atoi(row[0])==1){

	mysql_free_result(res); //libera la consulta que se realizó para verificar si la IP existe en la base de datos.
	strcpy(query,"Select digesto_de_verificacion from Equipos where Direccion_IP ='");
	strcat(query,direccionIP);//direccion IP
	strcat(query,"'");
	
	//printf("%s\n",query);

	if (mysql_query(conn,query))
	{ /* definicion de la consulta y el origen de la conexion */
		fprintf(stderr, "%s\n", mysql_error(conn));
		//digesto = "error"; //no reg	rese null
		return; 
	}	
	
	res = mysql_use_result(conn);

	//printf("resultado \n");	
	int i;
	//printf("%d \n",mysql_num_fields(res));


	while ((row = mysql_fetch_row(res)) != NULL) /* recorrer la variable res con todos los registros obtenidos para su uso */
		printf("Digesto de la direccion IP %s  es : %s\t \n",direccionIP,row[0]);
	
	//printf("regresa las columnas");

	mysql_free_result(res);
	mysql_close(conn);

	}
	else
	{

	printf("La direccion IP %s no está registrada \t \n",direccionIP);	
	
	}


}

void Consulta_Agentes(){
	MYSQL *conn; /* variable de conexión para MySQL */
	MYSQL_RES *res; /* variable que contendra el res	ultado de la consuta */
	MYSQL_ROW row; /* variable que contendra los campos por cada registro consultado */
	char *server = "localhost"; /*direccion del servidor 127.0.0.1, localhost o direccion ip */
	char *user = "root"; /*usuario para consultar la base de datos */
	char *password = "d4n13l.f"; /* contraseña para el usuario en cuestion */
	char *database = "Trabajo_Terminal_II"; /*nombre de la base de datos a consultar */
	conn = mysql_init(NULL); /*inicializacion a nula la conexión */
	char query[200];	
	
	char digesto[21];

	/* conectar a la base de datos */
	if (!mysql_real_connect(conn, server, user, password, database, 0, NULL, 0))
	{ /* definir los parámetros de la conexión antes establecidos */
		fprintf(stderr, "%s\n", mysql_error(conn)); /* si hay un error definir cual fue dicho error */
		//exit(1);
	return;
	}
	printf("conexion realizada con exito \n");

	if (mysql_query(conn,"select * from Equipos"))
	{ /* definicion de la consulta y el origen de la conexion */
		fprintf(stderr, "%s\n", mysql_error(conn));
		//exit(1);
	return;
	}

/*
create table Equipos(
ID int auto_increment primary key not null,
Direccion_IP varchar(15),
digesto_de_verificacion varchar(32),
verificado varchar(2),
conectado varchar(2)
);
*/


	res = mysql_use_result(conn);
	printf("ID\tDireccion IP\t\tDigesto de verificacion\t\tVerificado\t\tConectado\n");
	while ((row = mysql_fetch_row(res)) != NULL) /* recorrer la variable res con todos los registros obtenidos para su uso */
		printf("%s\t%s\t%s\t%s\t%s \n", row[0],row[1],row[2],row[3],row[4]); /* la variable row se convierte en un arreglo por el numero de campos que hay en la tabla */

	/* se libera la variable res y se cierra la conexión */
	mysql_free_result(res);
	mysql_close(conn);


}

int isIpv4(char ip[15]){
        int num;
        int flag = 1;
        int counter=0;
        char* p = strtok(ip,".");

        while (p && flag ){
                num = atoi(p);

                if (num>=0 && num<=255 && (counter++<4)){
                        flag=1;
                        p=strtok(NULL,".");

                }
                else{
                        flag=0;
                        break;
                }
        }

        return flag && (counter==3);

}


int bandera(char *cadena){

	char *ptr;
	char *aux[3];
	int corre =0;
	ptr = strtok( cadena,";" );    // Primera llamada => Primer token
	aux[0]= ptr;
/*	corre++;
  	printf( "%s\n", ptr );
   	while( (ptr = strtok( NULL,";" )) != NULL ){    // Posteriores llamadas
     	printf( "%s\n", ptr );
	aux[corre]=ptr;
	printf("corre en pos %d dice %s \n",corre,aux[corre]);
	corre++;
	}*/

return atoi(aux[0]);

}

char *digesto(char *cadena){

	printf("Entra a la funcion para regresar el digesto de la cadena\n");
	char *ptr;
	char *aux[3];
	int corre =0;
	printf("cadena %s \n",cadena);
	ptr = strtok( cadena,";" );    // Primera llamada => Primer token
	aux[0]= ptr;
	corre++;
  	printf( "%s\n", ptr );
   	while( (ptr = strtok( NULL,";" )) != NULL ){    // Posteriores llamadas
     	printf( "%s\n", ptr );
	aux[corre]=ptr;
	printf("corre en pos %d dice %s \n",corre,aux[corre]);
	corre++;	
	}

	printf("regresa aux en posicion 1 %s \n",aux[1]);
return aux[1];

}

	
