void Registra_nuevo();
void Obtiene_Digesto();

