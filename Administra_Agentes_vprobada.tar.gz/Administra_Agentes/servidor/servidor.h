#define PUERTO 5000
int bandera(char *cadena);
char *digesto(char *cadena);
void ValidaEquipoConectado(char* direccionIP, char *digesto);
void *funcionAgente(void *parametros);
int Conectar(char *direccionIP);
